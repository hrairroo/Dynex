#git remote add origin https://github.com/dynexcoin/dynex.git
#git branch -M main
#git push -u origin main

git add .
git commit -m "Update to Version 1.1"
git push origin main